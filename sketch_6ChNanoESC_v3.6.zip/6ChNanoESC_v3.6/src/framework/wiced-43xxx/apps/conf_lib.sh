#!/bin/bash

echo "Setting up apps/ifx/TLE94112 sym link..."
ln -s -r app ../../../../../../../apps/ifx/TLE94112
echo "Library configured successfully.
